<?php header('Content-type: text/plain'); ?>
text<p>P tag</p>